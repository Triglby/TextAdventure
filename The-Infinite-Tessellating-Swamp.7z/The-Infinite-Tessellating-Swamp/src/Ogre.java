
public class Ogre extends Character {

	
	public Ogre(String name, int hp, String position) {
		super(name, hp, position);
		
	}

	@Override
	public void updatePos(int row, int column) {
		setPosition(Integer.toString(row) + "," + Integer.toString(column));
	}

}
