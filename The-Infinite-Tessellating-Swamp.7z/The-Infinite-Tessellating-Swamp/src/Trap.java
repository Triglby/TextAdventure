
public class Trap extends Item {

	private int damage;
	
	public Trap(String name, String desc, String position, int damage) {
		super(name, desc, position);
		
		this.damage = damage;
	}
	
	@Override
	public void updatePos(int row, int column) {
		setPosition(Integer.toString(row) + "," + Integer.toString(column));
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}
	
}
