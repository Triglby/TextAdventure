
public interface Position {
	
	public void updatePos(int row, int column);
	
}
