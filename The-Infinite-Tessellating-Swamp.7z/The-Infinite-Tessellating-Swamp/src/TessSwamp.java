import java.util.*;

public class TessSwamp {

	boolean end;
	TileMap tm = new TileMap(10, 10);
	Player player = new Player("User", 3, "");
	Treasure treasure = new Treasure("Treasure", "It's the hidden treasure!", "");
	Trap trap = new Trap("spikes", "a spiky trap!", "", 1);
	Random rand = new Random();
	Scanner sc = new Scanner(System.in);
	String input;

	@SuppressWarnings("resource")
	public void play() {
		System.out.println(player.getPosition() + "   " + treasure.getPosition());
		System.out.println(trap.getPosition());
		System.out.println("\nWelcome to The Infinite Tessellating Swamp!");
		System.out.println("Enter a direction to move around the swamp...");
		System.out.println("The only way out is to find the hidden treasure...");
		System.out.println("Good Luck Adventurer!");

		do {
			input = sc.next();

			switch (input) {
			case "north":
				System.out.println("you moved north");
				if (player.getPosition().substring(0, 1).equals("0")) {
					player.updatePos(9, Integer.parseInt(player.getPosition().substring(2)));
					System.out.println(player.getPosition());
				} else {
					player.updatePos(Integer.parseInt(player.getPosition().substring(0, 1)) - 1,
							Integer.parseInt(player.getPosition().substring(2)));
					System.out.println(player.getPosition());
				}
				break;
			case "east":
				System.out.println("you moved east");
				if (player.getPosition().substring(2).equals("9")) {
					player.updatePos(Integer.parseInt(player.getPosition().substring(0, 1)), 0);
					System.out.println(player.getPosition());
				} else {
					player.updatePos(Integer.parseInt(player.getPosition().substring(0, 1)),
							Integer.parseInt(player.getPosition().substring(2)) + 1);
					System.out.println(player.getPosition());
				}
				break;
			case "south":
				System.out.println("you moved south");
				if (player.getPosition().substring(0, 1).equals("9")) {
					player.updatePos(0, Integer.parseInt(player.getPosition().substring(2)));
					System.out.println(player.getPosition());
				} else {
					player.updatePos(Integer.parseInt(player.getPosition().substring(0, 1)) + 1,
							Integer.parseInt(player.getPosition().substring(2)));
					System.out.println(player.getPosition());
				}
				break;
			case "west":
				System.out.println("you moved west");
				if (player.getPosition().substring(2).equals("0")) {
					player.updatePos(Integer.parseInt(player.getPosition().substring(0, 1)), 9);
					System.out.println(player.getPosition());
				} else {
					player.updatePos(Integer.parseInt(player.getPosition().substring(0, 1)),
							Integer.parseInt(player.getPosition().substring(2)) - 1);
					System.out.println(player.getPosition());
				}
				break;
			case "compass":
				System.out.print("the compass indicates you are this far away: ");
				System.out.printf("%.2f", player.useCompass(player.getPosition(), treasure.getPosition()));
				System.out.print("m\n");
				break;
			}

			if (player.getPosition().equals(treasure.getPosition())) {
				System.out.println("YOU HAVE FOUND THE TREASURE, IMBUEING YOU WITH THE POWER TO ESCAPE THE SWAMP!");
				end = true;
			}

			if (player.getPosition().equals(trap.getPosition())) {
				player.takeDamage(trap.getDamage());
				System.out.println("You stepped on a spike trap!... the spike mysteriously moves elsewhere...");
				System.out.println(player.getHp() + "/" + "3hp left!");

				trap.updatePos(rand.nextInt(10), rand.nextInt(10));

				while (trap.getPosition().equals(player.getPosition())
						|| trap.getPosition().equals(treasure.getPosition())) {
					trap.updatePos(rand.nextInt(10), rand.nextInt(10));
				}
			}

			if (player.getHp() <= 0) {
				System.out.println("looks like you died...");
				end = true;
			}

		} while (!end);

		System.out.println("Goodbye :)");
	}

	public void gameSetup() {
		end = false;
		tm.fillMap();
		player.updatePos(rand.nextInt(10), rand.nextInt(10));
		treasure.updatePos(rand.nextInt(10), rand.nextInt(10));
		trap.updatePos(rand.nextInt(10), rand.nextInt(10));

		if (player.getPosition().equals(treasure.getPosition())) {
			treasure.updatePos(rand.nextInt(10), rand.nextInt(10));
		}
		if (trap.getPosition().equals(player.getPosition()) || trap.getPosition().equals(treasure.getPosition())) {
			trap.updatePos(rand.nextInt(10), rand.nextInt(10));
		}

	}

}
