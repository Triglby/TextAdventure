
public abstract class Character implements Position {

	private String name;
	private int hp;
	private String position;

	public Character(String name, int hp, String position) {
		this.name = name;
		this.hp = hp;
		this.position = position;
	}
	
	public Character(int hp, String position) {
		this.hp = hp;
		this.position = position;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public void takeDamage(int damage) {
		setHp(this.hp - damage);
	}

}
