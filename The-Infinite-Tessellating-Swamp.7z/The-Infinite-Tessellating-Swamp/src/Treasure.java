
public class Treasure extends Item{

	public Treasure(String name, String desc, String position) {
		super(name, desc, position);
		
	}

	@Override
	public void updatePos(int row, int column) {
		setPosition(Integer.toString(row) + "," + Integer.toString(column));
		
	}
	
}
