public class App {

	public static void main(String[] args) {
		TessSwamp ts = new TessSwamp();
		ts.gameSetup();
		ts.play();
	}
}
