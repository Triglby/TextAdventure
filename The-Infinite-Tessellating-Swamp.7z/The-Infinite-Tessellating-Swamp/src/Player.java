
public class Player extends Character {

	private String hurtResponse;

	public Player(String name, int hp, String position) {
		super(name, hp, position);
		this.hurtResponse = "Ouch! My poor sweet ass :(";
	}

	@Override
	public void updatePos(int row, int column) {
		setPosition(Integer.toString(row) + "," + Integer.toString(column));
	}

	public float useCompass(String playerPos, String treasurePos) {
		int a = Integer.parseInt(playerPos.substring(0, 1)) - Integer.parseInt(treasurePos.substring(0, 1));
		int b = Integer.parseInt(playerPos.substring(2)) - Integer.parseInt(treasurePos.substring(2));

		float distance = (float) Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));

		return distance;
	}

	public String getHurtResponse() {
		return hurtResponse;
	}

	public void takeDamage(int damage) {
		setHp(getHp() - damage);
		System.out.println(hurtResponse);
	}
}
