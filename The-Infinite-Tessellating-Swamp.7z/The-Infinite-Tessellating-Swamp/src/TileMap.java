
public class TileMap {

	private String[][] map;

	public TileMap(int row, int column) {

		this.setMap(new String[row][column]);
	}

	public void setMap(String[][] map) {
		this.map = map;
	}

	public void fillMap() {
		for (int i = 0; i < map.length; i++) {
			System.out.println();
			for (int j = 0; j < map.length; j++) {
				map[i][j] = i + "," + j;

				// System.out.print(map[i][j] + " ");
			}
		}

	}

}
